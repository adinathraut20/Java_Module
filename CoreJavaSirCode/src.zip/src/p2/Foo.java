package p2;

public class Foo {
	public static int num = 100;
	public static void m1() {
		System.out.println("m1====");
	}
}
