package p1;

import static p2.Foo.*;

public class StaticImportDemo3 {

	public static void main(String[] args) {
		System.out.println(num);
		m1();
	}

}
