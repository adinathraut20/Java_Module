package p1;

public class StaticBlockDemo {
	
	static {
		System.out.println("static block called");
	}

	public static void main(String[] args) {
		System.out.println("main method called");

	}

}
