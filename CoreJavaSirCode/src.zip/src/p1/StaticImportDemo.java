package p1;

//import p2.*;
import p2.Foo;

public class StaticImportDemo {

	public static void main(String[] args) {
		System.out.println(Foo.num);
		Foo.m1();
	}

}
