package com.emp;
public class Employee{
	public Employee(){
		System.out.println("Employee");
	}
}