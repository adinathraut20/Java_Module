package d1;
public class SubClass extends Protection{
	public SubClass(){
	//	pr = 1;
		def = 2;
		prot = 3;
		pub = 4;	
	}
}