package d1;
public class Protection{
	private int pr;
	int def;
	protected int prot;
	public int pub;
	public Protection(){
		pr = 1;
		def = 2;
		prot = 3;
		pub = 4;	
	}
}