package d1;
public class NonSubClass{
	public NonSubClass(){
		Protection r = new Protection();
	//	r.pr = 1;
		r.def = 2;
		r.prot = 3;
		r.pub = 4;	
	}
}