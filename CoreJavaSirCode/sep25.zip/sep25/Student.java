package com.std;
public class Student{
	public Student(){
		System.out.println("Student");
	}
}