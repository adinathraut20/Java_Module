package com;
import com.std.Student;
import com.emp.Employee;
public class Main{
	public static void main(String args[]){
		Student s = new Student();
		Employee e = new Employee();
	}
}