package p1;

import java.util.Scanner;

public class Sum {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a num");
		int i = sc.nextInt();
		System.out.println("Enter another num");
		int j = sc.nextInt();
		int k = i + j;
		System.out.println("sum = "+k);

	}

}
