package p1;
public class Demo{
	public static void main(String args[]){
		System.out.println("Hello package !");
	}
}