class Foo{
	final void m1(){}
}
class Bar extends Foo{
	void m1(){}
}
class FinalDemo1{
	public static void main(String args[]){
		
	}
}