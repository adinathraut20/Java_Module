class FinalDemo{
	public static void main(String args[]){
		int i = 10;
		i = 20;
		final int j = 123;
		// j = 45;
		System.out.println(j);
		final float PI = 3.14f;
	}
}