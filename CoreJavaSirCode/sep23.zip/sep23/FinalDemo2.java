final class Foo{
	
}
class Bar extends Foo{
	
}
class FinalDemo2{
	public static void main(String args[]){
		
	}
}